<?php

namespace App\Http\Controllers;
  
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function index()
    {
        return view('auth.login');
    }

    public function login(Request $request){
        // validate data 
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);
        // login code 
        
        if(\Auth::attempt($request->only('email','password'))){
            $data = 'success';
            return $data;
            // return redirect('home');
        }

        return redirect('login')->withError('Login details are not valid');

    }

    public function register_view()
    {
        return view('auth.register');
    }

    public function register(Request $request){
        // validate 
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'email' => 'required|unique:users|email',
            'password'=>'required|confirmed'
        ]);

        // save in users table 
        User::create([
            'fname'=>$request->first_name,
            'lname'=>$request->last_name,
            'email'=>$request->email,
            'password'=> \Hash::make($request->password)
        ]);

        // login user here 
        
        if(\Auth::attempt($request->only('email','password'))){
            // return redirect('home');
            $data = 'success';
            return $data;
        }
        return redirect('register')->withError('Error');

    }

    public function home(){
        $data['data'] = User::get();
        return view('home', $data);
    }

     public function logout(){
        \Session::flush();
        \Auth::logout();
        return redirect('');
    }

    public function update(Request $request)
    {
        $id = $request->route('id');
        $data = User::where('id', $id)->first();
        
        if(empty($data->image)){
            $data->image = 'avatar.jpg';
        }
        return view('update', $data);

    }

    // public function edit(Request $request)
    // {
    //     $old_data = User::where('email', $request->email)->first();
    //     if ($request->image) {
    //         $fileN = public_path('img') . '/' . $old_data->image;
    //         if (File::exists($fileN))
    //             unlink($fileN);
    //     }
    //     if ($request->image) {
    //         $imageName = time().'.'.$request->image->extension();  
    //         $request->image->move(public_path('img'), $imageName);
    //     }
    //     if(empty($request->image)){
    //         $imageName = $old_data->image;
    //     }
    //     User::where('email', $request->email)
    //         ->update([
    //             'fname' => $request->fname, 'lname' => $request->lname, 'image' => $imageName
    //         ]);

    //     return redirect('update/'.$old_data->id);
    // }

    public function edit(Request $request)
    {
        $request->validate([
            'fname'=>'required',
            'lname'=>'required'
        ]);

        $old_data = User::where('email', $request->email)->first();
        if ($request->image) {
            $fileN = public_path('img') . '/' . $old_data->image;
            if (File::exists($fileN))
                unlink($fileN);
        }
        if ($request->image) {
            $imageName = time().'.'.$request->image->extension();  
            $request->image->move(public_path('img'), $imageName);
        }
        if(empty($request->image)){
            $imageName = $old_data->image;
        }
        User::where('email', $request->email)
            ->update([
                'fname' => $request->fname, 'lname' => $request->lname, 'image' => $imageName
            ]);
        $data['status'] = 'success';
        $data['data'] = $old_data->id;
        return $data;
    }

    
}
