@extends('layouts.app')

@section('content')

    <?php $id = Auth::user()->id; ?>
    <div class="container">
        {!! QrCode::size(75)->generate('http://127.0.0.1:8000/update/'.$id) !!}
    </div>
    
<table class="table mt-5 container">
    <thead class="table-dark">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($data as $rec){ ?>
        <tr>
            <td>{{$rec->fname}}</td>
            <td>{{$rec->lname}}</td>
            <td>{{$rec->email}}</td>
        </tr>
        <?php } ?>
    </tbody>
</table>


@endsection