@extends('layouts.app')

@section('content')

    <div class="col-md-6 col-sm-12 mx-auto">
    <span class="text-danger" id="err-msg"></span>
        <form id="myForm">
            <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}" />
            <div class="text-center">
                <img type="image" name="image" src="{{url('img').'/'.$image}}" width="50px"/>
                <br><input type="file" name="image" id="image"/>
            </div>
            <div class="form-group">
                <label for="">First Name:</label>
                <input type="text" class="form-control" name="fname" id="fname" value="{{$fname}}">
                <span class="text-danger" id="fname-err"></span>
            </div>
            <div class="form-group">
                <label for="">Last Name:</label>
                <input type="text" class="form-control" name="lname" id="lname" value="{{$lname}}">
                <span class="text-danger" id="lname-err"></span>
            </div>
            <div class="form-group">
                <label for="">Email:</label>
                <input type="email" class="form-control" name="email" id="email" value="{{$email}}" readonly>
            </div>
            <button type="submit" class="btn btn-success">submit</button>
        </form>
    </div>

<script>
    $('#myForm').submit(function(e){
        e.preventDefault();
        var formData = new FormData(this);
        var url = "{{url('/edit')}}";
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                console.log(data);
                if(data.status == 'success'){
                    window.location.replace(data.data);
                }else{
                    $('#err-msg').html('details are not matched');
                }
            },
            error: function(data){
                $('#err-msg').html(data.responseText);
                console.log(data.responseText);
            }
        });
    });
</script>
@endsection