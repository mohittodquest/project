<?php $__env->startSection('content'); ?>

    <?php $id = Auth::user()->id; ?>
    <div class="container">
        <?php echo QrCode::size(75)->generate('http://127.0.0.1:8000/update/'.$id); ?>

    </div>
    
<table class="table mt-5 container">
    <thead class="table-dark">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($data as $rec){ ?>
        <tr>
            <td><?php echo e($rec->fname); ?></td>
            <td><?php echo e($rec->lname); ?></td>
            <td><?php echo e($rec->email); ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mohit\Desktop\mohit\resources\views/home.blade.php ENDPATH**/ ?>