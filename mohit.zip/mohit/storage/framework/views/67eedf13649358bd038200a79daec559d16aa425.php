

<?php $__env->startSection('content'); ?>

    <div class="col-md-6 col-sm-12 mx-auto">
    <span class="text-danger" id="err-msg"></span>
        <form id="myForm">
            <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>" />
            <div class="text-center">
                <img type="image" name="image" src="<?php echo e(url('img').'/'.$image); ?>" width="50px"/>
                <br><input type="file" name="image" id="image"/>
            </div>
            <div class="form-group">
                <label for="">First Name:</label>
                <input type="text" class="form-control" name="fname" id="fname" value="<?php echo e($fname); ?>">
                <span class="text-danger" id="fname-err"></span>
            </div>
            <div class="form-group">
                <label for="">Last Name:</label>
                <input type="text" class="form-control" name="lname" id="lname" value="<?php echo e($lname); ?>">
                <span class="text-danger" id="lname-err"></span>
            </div>
            <div class="form-group">
                <label for="">Email:</label>
                <input type="email" class="form-control" name="email" id="email" value="<?php echo e($email); ?>" readonly>
            </div>
            <button type="submit" class="btn btn-success">submit</button>
        </form>
    </div>

<script>
    $('#myForm').submit(function(e){
        e.preventDefault();
        var formData = new FormData(this);
        var url = "<?php echo e(url('/edit')); ?>";
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                console.log(data);
                if(data.status == 'success'){
                    window.location.replace(data.data);
                }else{
                    $('#err-msg').html('details are not matched');
                }
            },
            error: function(data){
                $('#err-msg').html(data.responseText);
                console.log(data.responseText);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mohit\Desktop\mohit\resources\views/update.blade.php ENDPATH**/ ?>