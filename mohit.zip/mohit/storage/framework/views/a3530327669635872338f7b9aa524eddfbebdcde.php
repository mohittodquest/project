<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">

            <div class="col-md-4 offset-md-4">
                <div class="card form-holder">
                    <div class="card-body">
                        <h1>Login</h1>

                        <?php if(Session::has('error')): ?>
                            <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <p class="text-success"><?php echo e(Session::get('success')); ?></p>
                        <?php endif; ?>
                        <span class="text-danger" id="err-msg"></span>
                        <form data-action="<?php echo e(route('login')); ?>" id="login-form" method="post">
                            <!-- <?php echo csrf_field(); ?> -->
                            <?php echo method_field('post'); ?>
                            <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>" />
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Email" />
                                <?php if($errors->has('email')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" id="password" class="form-control" placeholder="Password" />
                                <?php if($errors->has('password')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <!-- <div class="col-8 text-left">
                                    <a href="#" class="btn btn-link">Forgot Password</a>
                                </div> -->
                                <div class="col-12 text-right">
                                    <input type="submit" id="login-sbmt" class="btn btn-primary" value=" Login " />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).on('click','#login-sbmt', function(e){
            e.preventDefault();
            let email = $('#email').val();
            let password = $('#password').val();
            var url = $('#login-form').attr('data-action');
            var home_url = "<?php echo e(url('home')); ?>";
            var token = $('#_token').val();
            $.ajax({
                url: url,
                type: 'POST',
                headers: {
                            'X-CSRF-Token': token 
                        },
                data: {email: email, password: password},
                success: function(data){
                    console.log(data);
                    if(data == 'success'){
                        window.location.replace(home_url);
                    }else{
                        $('#err-msg').html('details are not matched');
                    }
                    
                },
                error: function(data){
                    $('#err-msg').html(data.responseText);
                    console.log(data.responseText);
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mohit\Desktop\mohit\resources\views/auth/login.blade.php ENDPATH**/ ?>