<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">

            <div class="col-md-4 offset-md-4">
                <div class="card form-holder">
                    <div class="card-body">
                        <h1>Register</h1>

                        <?php if(Session::has('error')): ?>
                            <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
                        <?php endif; ?>
                        <span class="text-danger" id="err-msg"></span>
                        <form data-action="<?php echo e(route('register')); ?>" method="post" id="register-form">
                            <!-- <?php echo csrf_field(); ?> -->
                            <?php echo method_field('post'); ?>
                            <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>" />
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" id="fname" class="form-control" placeholder="first name" />
                                <?php if($errors->has('first_name')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('first_name')); ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" id="lname" class="form-control" placeholder="last name" />
                                <?php if($errors->has('last_name')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('last_name')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" id="email" class="form-control" placeholder="Email" />
                                <?php if($errors->has('email')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" id="password" class="form-control" placeholder="Password" />
                                <?php if($errors->has('password')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" id="password_confirmation" class="form-control"
                                    placeholder="Password Confirmation" />
                            </div>

                            <div class="row">
                                <!-- <div class="col-8 text-left">
                                    <a href="#" class="btn btn-link">Forgot Password</a>
                                </div> -->
                                <div class="col-12 text-right">
                                    <input type="submit" id="btn-register" class="btn btn-primary" value=" Register " />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).on('click','#btn-register', function(e){
            e.preventDefault();
            let fname = $('#fname').val();
            let lname = $('#lname').val();
            let email = $('#email').val();
            let password = $('#password').val();
            let password_confirmation = $('#password_confirmation').val();
            var url = $('#register-form').attr('data-action');
            var home_url = "<?php echo e(url('home')); ?>";
            var token = $('#_token').val();
            $.ajax({
                url: url,
                type: 'POST',
                headers: {
                            'X-CSRF-Token': token 
                        },
                data: {first_name:fname,last_name:lname,email: email, password: password,password_confirmation:password_confirmation},
                success: function(data){
                    console.log(data);
                    if(data == 'success'){
                        window.location.replace(home_url);
                    }else{
                        $('#err-msg').html('details are not matched');
                    }
                },
                error: function(data){
                    // alert(data.responseText);
                    $('#err-msg').html(data.responseText);
                    console.log(data.responseText);
                }
                
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mohit\Desktop\ajay\resources\views/auth/register.blade.php ENDPATH**/ ?>